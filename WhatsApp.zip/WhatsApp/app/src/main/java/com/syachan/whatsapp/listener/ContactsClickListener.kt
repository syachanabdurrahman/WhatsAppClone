package com.syachan.whatsapp.listener

interface ContactsClickListener {
    fun onContactClicked(name: String?, phone: String?)
}