package com.syachan.whatsapp.listener

interface FailureCallback {
    fun onUserError()
}