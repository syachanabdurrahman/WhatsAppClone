package com.syachan.whatsapp.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.WriteBatch
import com.syachan.whatsapp.R
import com.syachan.whatsapp.adapter.ChatsAdapter
import com.syachan.whatsapp.listener.ChatClickListener
import com.syachan.whatsapp.listener.FailureCallback
import com.syachan.whatsapp.util.Chat
import com.syachan.whatsapp.util.DATA_CHATS
import com.syachan.whatsapp.util.DATA_USERS
import com.syachan.whatsapp.util.DATA_USER_CHATS
import kotlinx.android.synthetic.main.fragment_chat.*

class ChatFragment : Fragment(), ChatClickListener {

    private var chatsAdapter = ChatsAdapter(arrayListOf())
    private val firebaseDb : FirebaseFirestore = FirebaseFirestore.getInstance()
    private val userId : String? = FirebaseAuth.getInstance().currentUser?.uid
    private var failureCallback: FailureCallback?= null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_chat, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (userId.isNullOrEmpty()){
            failureCallback?.onUserError()
        }
    }

    fun setFailureCallback(listener: FailureCallback){
        failureCallback = listener
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        chatsAdapter.setOnItemClickListener(this)
        rv_chats.apply {
            setHasFixedSize(false)
            layoutManager = LinearLayoutManager(context)
            adapter = chatsAdapter
            addItemDecoration(DividerItemDecoration(context,DividerItemDecoration.VERTICAL))
        }

        firebaseDb.collection(DATA_USERS).document(userId!!)
            .addSnapshotListener{documentSnapshot : DocumentSnapshot? , firebaseFirestoreException ->
                if (firebaseFirestoreException == null) {
                    refreshChat()
                }
            }
    }

    private fun refreshChat() {
        firebaseDb.collection(DATA_USERS).document(userId!!).get()
            .addOnSuccessListener {
                if (it.contains(DATA_USER_CHATS)) {
                    val patners: Any? = it[DATA_USER_CHATS]
                    val chats: ArrayList<String> = arrayListOf<String>()

                    for (patner: String in (patners as HashMap<String, String>).keys) {
                        if (patners[patner] != null) {//melakukan p
                            chats.add(patners[patner]!!)
                        }
                    }

                    chatsAdapter.updateChats(chats)
                }
            }
            .addOnFailureListener {
                it.printStackTrace()
            }
    }

    override fun onChatClicked(
        name: String?,
        otherUserId: String?,
        chatsImageUrl: String?,
        chatsName: String?
    ) {
        Toast.makeText(context, "$name, clicked", Toast.LENGTH_SHORT).show()
    }

    fun newChat(patnerId: String){
        firebaseDb.collection(DATA_USERS).document(userId!!).get()
            .addOnSuccessListener { userDocument  : DocumentSnapshot ->
                val userChatPatners : HashMap<String, String> = hashMapOf<String, String>()
                if (userDocument[DATA_USER_CHATS] != null &&
                            userDocument[DATA_USER_CHATS] is HashMap<*,*>){
                    val userDocumentMap : HashMap<String, String> = userDocument[DATA_USER_CHATS] as HashMap<String, String>
                    if (userDocumentMap.containsKey(patnerId)){
                        return@addOnSuccessListener
                    } else {
                        userChatPatners.putAll(userDocumentMap)
                    }
                }

                firebaseDb.collection(DATA_USERS)
                    .document(patnerId)
                    .get()
                    .addOnSuccessListener { patnerDocument: DocumentSnapshot ->
                        val patnerChatPatners : HashMap<String, String> = hashMapOf<String, String>()
                            if (patnerDocument[DATA_USER_CHATS] !=null &&
                                    patnerDocument[DATA_USER_CHATS] is HashMap<*,*>) {
                                val patnerDocumentMap: HashMap<String, String> = patnerDocument[DATA_USER_CHATS] as HashMap<String, String>
                                patnerChatPatners.putAll(patnerDocumentMap)
                            }

                        val chatParticipants : ArrayList<String> = arrayListOf(userId, patnerId)
                        val chat = Chat(chatParticipants)
                        val chatRef : DocumentReference = firebaseDb.collection(DATA_CHATS).document()
                        val userRef : DocumentReference = firebaseDb.collection(DATA_USERS).document(userId)
                        val patnerRef : DocumentReference = firebaseDb.collection(DATA_USERS).document(patnerId)
                        userChatPatners[patnerId] = chatRef.id
                        patnerChatPatners[userId] = chatRef.id

                        val batch : WriteBatch = firebaseDb.batch()
                        batch.set(chatRef, chat)
                        batch.update(userRef, DATA_USER_CHATS, userChatPatners)
                        batch.update(patnerRef, DATA_USER_CHATS, patnerChatPatners)
                        batch.commit()
                        }
                    .addOnFailureListener {
                        it.printStackTrace()
                    }
            }

            .addOnFailureListener {
                it.printStackTrace()
            }
    }
}